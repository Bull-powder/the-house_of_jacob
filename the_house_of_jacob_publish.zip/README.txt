THE HOUSE OF JACOB — STAGE 2: FLASK + SQLITE ACCOUNTS

REQUIREMENTS
- Python 3.10 or newer recommended
- Internet connection for the one-time Flask installation

WINDOWS SETUP
1. Extract this ZIP file to a folder such as Documents\the_house_of_jacob_stage2.
2. Open Command Prompt in that folder (File Explorer address bar: type cmd and press Enter).
3. Run: py -m pip install -r requirements.txt
4. Run: py app.py
5. Open Microsoft Edge and visit: http://127.0.0.1:5000
6. Create an account, sign out, sign back in, and test editing your profile.
7. To stop the server, return to Command Prompt and press Ctrl+C.

WHAT THIS STAGE DOES
- Flask backend in Python
- SQLite database file created automatically on first run
- Registration and sign-in with password hashes (not plaintext passwords)
- Session-based login state
- Profile editing: display name, bio, interests
- Basic parameterized SQL and login-required checks

IMPORTANT
- This is a local learning project, not ready for public deployment.
- It has no email verification, password reset, CSRF protection, rate limiting, account deletion, moderation, or public hosting.
- The default Flask secret is for local learning only. Before any deployment, configure a long random secret via HOUSE_OF_JACOB_SECRET and use HTTPS, secure cookie settings, CSRF protection, rate limits, and security review.
- Never collect sensitive personal information in this prototype.
