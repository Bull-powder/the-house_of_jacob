THE HOUSE OF JACOB — PUBLISHING STARTER (FLASK + SQLITE)

WHAT THIS BUNDLE DOES
- Adds Gunicorn production start configuration.
- Lets the SQLite database path be configured with HOUSE_OF_JACOB_DB_PATH.
- Requires HOUSE_OF_JACOB_SECRET on Render instead of using the local demo secret.
- Adds secure cookie flags for HTTPS hosting.
- Includes .gitignore to avoid committing local databases and secrets.

IMPORTANT SCOPE
This publishes the Stage 2 account/profile application, not the full social network yet.
Posts, comments, interest-group membership, private messaging, moderation, password reset,
email verification, and stronger production protections still need to be built.
Do not invite public users or collect sensitive information until these are implemented and reviewed.

GITHUB STEPS
1. Sign in to GitHub.
2. Create a NEW repository named the-house-of-jacob. Keep it private while developing.
3. Extract this ZIP. Upload the CONTENTS of this folder to the repository root (app.py, Procfile,
   requirements.txt, templates/, static/, etc.). Do not upload house_of_jacob.db or .env.
4. Commit the files to the main branch.

RENDER STEPS
1. Create a Render account at https://render.com/
2. Open the Render Dashboard and choose New > Web Service.
3. Connect GitHub, choose the-house-of-jacob repository, and select branch main.
4. Set Language/Runtime: Python.
5. Build Command: pip install -r requirements.txt
6. Start Command: gunicorn app:app
7. For a version that keeps SQLite data across restarts, choose a paid web service and add a persistent disk:
   - Mount path: /var/data
   - Set environment variable HOUSE_OF_JACOB_DB_PATH=/var/data/house_of_jacob.db
   Free Render web services have ephemeral filesystems; SQLite account data can be lost on restart/deploy.
8. Set environment variable HOUSE_OF_JACOB_SECRET to a long, random secret generated privately.
   Do not paste the secret into chat or commit it to GitHub.
9. Deploy and open the onrender.com URL shown by Render.

COST / DATA WARNING
Render free web services can be used for a preview, but their filesystem is ephemeral and the service
can sleep when idle. Do not use a free SQLite deployment for real user accounts. A persistent disk
requires a paid web service. Another route is to change the app to use a managed PostgreSQL database;
the current code in this bundle is SQLite and is not yet wired to PostgreSQL.

BEFORE PUBLIC LAUNCH
- Add CSRF protection, login rate limiting, email verification and password reset.
- Add account deletion and privacy/data deletion process.
- Add content moderation, report/block functionality, abuse handling and terms/community rules.
- Add automated backups and test recovery.
- Add database migration and security review.
- Use HTTPS and secure production secrets.
